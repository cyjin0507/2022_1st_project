create table userTable(
id varchar(20),
password varchar(20),
name varchar(20),
nickname varchar(20),
major varchar(20)/*,
idx int,
type check,  /* 교사, 학생 구별*/
start_date date,
reserved1 varchar(20),
reserved2 varchar(20)*/
);

select * from userTable;

drop table userTable;

delete userTable;